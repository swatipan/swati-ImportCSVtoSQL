﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using Import_CSV_SqlDB_MVC.Models;

/// <summary>
/// created by - swati rastogi
/// created on - 6th nov 2018
/// Aim- Import csv,validate and display results
/// </summary>
namespace Import_CSV_SqlDB_MVC.Controllers
{
   
    public class HomeController : Controller
    {
        public string ErrorMessage { get; set; }
        public decimal filesize { get; set; }

        // GET: Home
        public ActionResult Index()
        {
            return View(BindGrid());
        }

        [HttpPost]
        public ActionResult Index(HttpPostedFileBase postedFile)
        {
            UploadUserFile(postedFile);//validate file beofre uploading
            string filePath = string.Empty;
            
            if (postedFile != null && postedFile.ContentLength >0) //checking empty files
            {
                string path = Server.MapPath("~/Uploads/");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                filePath = path + Path.GetFileName(postedFile.FileName);
                string extension = Path.GetExtension(postedFile.FileName);
                postedFile.SaveAs(filePath);

                //Create a DataTable.
                DataTable dt = new DataTable();
                dt.Columns.AddRange(new DataColumn[5] {                            
                                new DataColumn("Name", typeof(string)),
                                new DataColumn("DateCreated",typeof(DateTime)),
                                 new DataColumn("CGPA",typeof(Double)),
                                  new DataColumn("Age", typeof(int)),
                                  new DataColumn("GUID",typeof(string))
                });


                //Read the contents of CSV file.
                string csvData = System.IO.File.ReadAllText(filePath);

                //Execute a loop over the rows.
                foreach (string row in csvData.Split('\n'))
                {
                    if (!string.IsNullOrEmpty(row))
                    {
                        dt.Rows.Add();
                        int i = 0;

                        //Execute a loop over the columns.
                        foreach (string cell in row.Split(','))
                        {
                            dt.Rows[dt.Rows.Count - 1][i] = cell;
                            i++;
                        }
                    }
                }

                string conString = ConfigurationManager.ConnectionStrings["DataBaseConnectionString"].ConnectionString;
                using (SqlConnection con = new SqlConnection(conString))
                {
                    using (SqlBulkCopy sqlBulkCopy = new SqlBulkCopy(con))
                    {
                        //Set the database table name.
                        sqlBulkCopy.DestinationTableName = "dbo.Students";

                        //[OPTIONAL]: Map the DataTable columns with that of the database table
                        sqlBulkCopy.ColumnMappings.Add("Name", "Name");
                        sqlBulkCopy.ColumnMappings.Add("DateCreated", "DateCreated");
                        sqlBulkCopy.ColumnMappings.Add("CGPA", "CGPA");
                        sqlBulkCopy.ColumnMappings.Add("Age", "Age");
                        sqlBulkCopy.ColumnMappings.Add("GUID", "GUID");
                        con.Open();
                        sqlBulkCopy.WriteToServer(dt);
                        con.Close();
                    }
                }
            }

            return View(BindGrid());

        }

        List<Modeldata> BindGrid()
        {
            List<Modeldata> lmd = new List<Modeldata>();

            //creating list of model.  

            DataSet ds = new DataSet();

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DataBaseConnectionString"].ToString());
            SqlCommand cmd = new SqlCommand("GetDetails_Students", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            da.Fill(ds);

            if (ds != null && ds.Tables.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)

                // loop for adding add from dataset to list<modeldata>  
                {
                    lmd.Add(new Modeldata
                    {
                        // adding data from dataset row in to list<modeldata>  

                        Name = (dr["Name"]).ToString(),
                        DateCreated = Convert.ToDateTime(dr["DateCreated"]),
                        CGPA = Convert.ToDouble(dr["CGPA"]),
                        Age = Convert.ToInt32(dr["Age"]),
                        GUID = dr["GUID"].ToString()
                    });
                }
            }
            else
            {
                
            }

            return lmd;

        }

        public string UploadUserFile(HttpPostedFileBase file)
        {
            try
            {
                var supportedTypes = new[] { "csv" };
                var fileExt = System.IO.Path.GetExtension(file.FileName).Substring(1);
                if (!supportedTypes.Contains(fileExt))
                {
                    ErrorMessage = "File Extension Is InValid - Only Upload CSV File";
                    return ErrorMessage;
                }
                else if (file.ContentLength > (filesize * 1024))
                {
                    ErrorMessage = "File size Should Be UpTo " + filesize + "KB";
                    return ErrorMessage;
                }
                else
                {
                    ErrorMessage = "";
                    return ErrorMessage;
                }
            }
            catch (Exception ex)
            {
                ErrorMessage = "Upload Container Should Not Be Empty or Contact Admin";
                return ErrorMessage;
            }
        }
    }
}